import{z as a}from"./Bl9MByqY.js";a();
