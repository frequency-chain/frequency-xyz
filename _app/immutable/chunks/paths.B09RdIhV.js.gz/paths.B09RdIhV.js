var s;const a=((s=globalThis.__sveltekit_b6wb6b)==null?void 0:s.base)??"";var b;const e=((b=globalThis.__sveltekit_b6wb6b)==null?void 0:b.assets)??a;export{e as a,a as b};
