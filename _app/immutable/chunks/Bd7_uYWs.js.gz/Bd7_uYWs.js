var s;const l=((s=globalThis.__sveltekit_slke8l)==null?void 0:s.base)??"";var e;const a=((e=globalThis.__sveltekit_slke8l)==null?void 0:e.assets)??l;export{a,l as b};
