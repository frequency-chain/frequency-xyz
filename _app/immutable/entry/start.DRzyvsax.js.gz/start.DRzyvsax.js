import{l as o,a as r}from"../chunks/Cx5a6yEh.js";export{o as load_css,r as start};
