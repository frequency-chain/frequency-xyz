import{a as t}from"../chunks/entry.jq-lgvM_.js";export{t as start};
