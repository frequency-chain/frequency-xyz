import{a as t}from"../chunks/entry.CyB2HqFl.js";export{t as start};
