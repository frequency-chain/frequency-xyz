import{a as t}from"../chunks/entry.CGl2DSrK.js";export{t as start};
