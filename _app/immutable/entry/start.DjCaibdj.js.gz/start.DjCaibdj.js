import{a as t}from"../chunks/entry.CBFG0Xb_.js";export{t as start};
