import{a as t}from"../chunks/entry.DRs9-iYe.js";export{t as start};
