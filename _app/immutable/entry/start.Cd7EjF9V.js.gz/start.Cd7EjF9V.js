import{a as t}from"../chunks/entry.20Z6qzSj.js";export{t as start};
