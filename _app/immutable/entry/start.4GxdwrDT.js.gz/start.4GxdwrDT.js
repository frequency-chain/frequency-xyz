import{a as t}from"../chunks/entry.BeG7g8ed.js";export{t as start};
