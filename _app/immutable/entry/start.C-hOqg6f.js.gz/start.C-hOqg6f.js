import{a as t}from"../chunks/entry.QeSh1lF3.js";export{t as start};
