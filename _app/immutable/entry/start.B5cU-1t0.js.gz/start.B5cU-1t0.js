import{a as t}from"../chunks/entry.BdQziI-3.js";export{t as start};
