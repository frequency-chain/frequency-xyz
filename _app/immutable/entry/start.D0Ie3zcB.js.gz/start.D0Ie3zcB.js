import{a as t}from"../chunks/entry.DG8xnnxL.js";export{t as start};
