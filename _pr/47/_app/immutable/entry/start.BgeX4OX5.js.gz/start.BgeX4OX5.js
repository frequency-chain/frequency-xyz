import{a as t}from"../chunks/entry.CUA0ktkR.js";export{t as start};
