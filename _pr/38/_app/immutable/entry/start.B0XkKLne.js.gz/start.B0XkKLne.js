import{a as t}from"../chunks/entry.Bg3lZ9q9.js";export{t as start};
