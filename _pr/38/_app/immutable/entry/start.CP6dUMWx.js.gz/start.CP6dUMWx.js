import{a as t}from"../chunks/entry.CM2x0VOR.js";export{t as start};
