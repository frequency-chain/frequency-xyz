import{a as t}from"../chunks/entry.CMxYNahO.js";export{t as start};
