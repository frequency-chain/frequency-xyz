import{b as c,E as s,a as i,h as r,c as h,p,d}from"./runtime.CKQ2EtY3.js";function u(t,f,o){r&&h();var n=t,a,e;c(()=>{a!==(a=f())&&(e&&(p(e),e=null),a&&(e=i(()=>o(n,a))))},s),r&&(n=d)}export{u as c};
