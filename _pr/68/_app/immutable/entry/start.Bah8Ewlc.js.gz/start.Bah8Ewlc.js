import{a as t}from"../chunks/entry.BDKikPhv.js";export{t as start};
