import{a as t}from"../chunks/entry.hkr2JvpV.js";export{t as start};
