import{a as t}from"../chunks/entry.BreZfEBb.js";export{t as start};
