import{a as t}from"../chunks/entry.zl_AUtP-.js";export{t as start};
