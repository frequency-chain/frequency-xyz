import{a as t}from"../chunks/entry.CoomOoUz.js";export{t as start};
