var s;const e=((s=globalThis.__sveltekit_mm94bg)==null?void 0:s.base)??"/_pr/92";var a;const t=((a=globalThis.__sveltekit_mm94bg)==null?void 0:a.assets)??e;export{t as a,e as b};
