import{a as t}from"../chunks/entry.DO-q--dJ.js";export{t as start};
