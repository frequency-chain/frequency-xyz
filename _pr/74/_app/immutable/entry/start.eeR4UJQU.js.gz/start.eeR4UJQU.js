import{a as t}from"../chunks/entry.DQE76oPx.js";export{t as start};
