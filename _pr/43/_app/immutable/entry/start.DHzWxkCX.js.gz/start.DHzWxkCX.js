import{a as t}from"../chunks/entry.C56oQsQz.js";export{t as start};
