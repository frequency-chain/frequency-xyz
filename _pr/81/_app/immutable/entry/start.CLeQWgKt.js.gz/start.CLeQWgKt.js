import{a as t}from"../chunks/entry.DJ-ugFEu.js";export{t as start};
