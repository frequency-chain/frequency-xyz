import{a as t}from"../chunks/entry.CRp1WNWy.js";export{t as start};
