import{a as t}from"../chunks/entry.CvavvHkv.js";export{t as start};
