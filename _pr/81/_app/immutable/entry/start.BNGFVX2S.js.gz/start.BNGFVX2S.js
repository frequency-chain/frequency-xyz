import{a as t}from"../chunks/entry.BCX0Vhm-.js";export{t as start};
