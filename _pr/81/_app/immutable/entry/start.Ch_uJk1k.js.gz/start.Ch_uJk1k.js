import{a as t}from"../chunks/entry.CT_R0OGE.js";export{t as start};
