var s;const e=((s=globalThis.__sveltekit_1n0hn0f)==null?void 0:s.base)??"/_pr/45";var a;const t=((a=globalThis.__sveltekit_1n0hn0f)==null?void 0:a.assets)??e;export{t as a,e as b};
