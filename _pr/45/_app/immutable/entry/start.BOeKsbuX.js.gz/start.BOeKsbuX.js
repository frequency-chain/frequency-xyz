import{a as t}from"../chunks/entry.0rKBRamO.js";export{t as start};
