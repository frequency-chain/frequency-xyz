import{a as t}from"../chunks/entry.DPnA6snj.js";export{t as start};
