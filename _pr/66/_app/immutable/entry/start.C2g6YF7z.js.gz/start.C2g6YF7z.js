import{a as t}from"../chunks/entry.CPzJ6dIo.js";export{t as start};
