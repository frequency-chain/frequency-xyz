import{a as t}from"../chunks/entry.oVGrd6BO.js";export{t as start};
