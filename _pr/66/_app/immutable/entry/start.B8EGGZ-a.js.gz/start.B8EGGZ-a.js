import{a as t}from"../chunks/entry.B6P1EA4T.js";export{t as start};
