import{a as t}from"../chunks/entry.ZMDH7KXh.js";export{t as start};
