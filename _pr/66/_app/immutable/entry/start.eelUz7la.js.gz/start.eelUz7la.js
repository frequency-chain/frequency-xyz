import{a as t}from"../chunks/entry.DllgILsv.js";export{t as start};
