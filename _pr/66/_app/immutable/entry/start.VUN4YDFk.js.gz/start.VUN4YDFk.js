import{a as t}from"../chunks/entry.BLXhT5Zy.js";export{t as start};
