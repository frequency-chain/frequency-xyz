import{D as a}from"./runtime.C4I2mAsz.js";a();
