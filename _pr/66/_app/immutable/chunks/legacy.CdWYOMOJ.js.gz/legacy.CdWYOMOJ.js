import{D as a}from"./runtime.DBv6Fr_6.js";a();
