var s;const a=((s=globalThis.__sveltekit_65j0t5)==null?void 0:s.base)??"/_pr/106";var t;const e=((t=globalThis.__sveltekit_65j0t5)==null?void 0:t.assets)??a;export{e as a,a as b};
