import{a as t}from"../chunks/entry.Pj_M_IFB.js";export{t as start};
