import{a as t}from"../chunks/entry.DA18ZZ9J.js";export{t as start};
