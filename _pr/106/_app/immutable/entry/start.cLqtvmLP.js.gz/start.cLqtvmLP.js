import{a as t}from"../chunks/entry.B1vIR7oW.js";export{t as start};
