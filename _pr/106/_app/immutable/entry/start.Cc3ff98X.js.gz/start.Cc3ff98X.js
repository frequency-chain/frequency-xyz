import{a as t}from"../chunks/entry.C3wsK--L.js";export{t as start};
