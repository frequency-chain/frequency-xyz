import{a as t}from"../chunks/entry.C7gDvxQT.js";export{t as start};
