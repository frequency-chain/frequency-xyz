import{a as t}from"../chunks/entry.zjLN9U2Q.js";export{t as start};
