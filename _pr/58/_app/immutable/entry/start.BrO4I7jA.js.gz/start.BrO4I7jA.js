import{a as t}from"../chunks/entry.C9DskIin.js";export{t as start};
