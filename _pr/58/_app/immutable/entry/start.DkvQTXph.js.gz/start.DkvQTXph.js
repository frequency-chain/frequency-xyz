import{a as t}from"../chunks/entry.DKfyzb6l.js";export{t as start};
