import{a as t}from"../chunks/entry.CF_BeJWU.js";export{t as start};
