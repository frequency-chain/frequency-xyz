import{a as t}from"../chunks/entry.Daj8fxWy.js";export{t as start};
