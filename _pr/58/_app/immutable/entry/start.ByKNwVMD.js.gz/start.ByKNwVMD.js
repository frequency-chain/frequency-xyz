import{a as t}from"../chunks/entry.CcehL1OW.js";export{t as start};
