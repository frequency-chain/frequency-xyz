import{a as t}from"../chunks/entry.DLA1py3W.js";export{t as start};
