import{a as t}from"../chunks/entry.DDa76knB.js";export{t as start};
