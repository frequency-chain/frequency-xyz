import{a as t}from"../chunks/entry.BGB9b3su.js";export{t as start};
