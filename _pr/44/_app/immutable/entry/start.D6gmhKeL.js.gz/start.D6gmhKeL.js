import{a as t}from"../chunks/entry.D5h7Hjhj.js";export{t as start};
