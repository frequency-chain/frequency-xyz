import{a as t}from"../chunks/entry.D6uCRoyP.js";export{t as start};
