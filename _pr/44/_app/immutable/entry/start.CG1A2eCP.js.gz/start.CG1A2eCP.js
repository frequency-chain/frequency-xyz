import{a as t}from"../chunks/entry.B_9MP3L6.js";export{t as start};
