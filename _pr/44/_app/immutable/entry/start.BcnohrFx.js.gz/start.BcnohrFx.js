import{a as t}from"../chunks/entry.Cnn5JSXJ.js";export{t as start};
