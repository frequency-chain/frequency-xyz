import{a as t}from"../chunks/entry.ByTRLnlq.js";export{t as start};
