import{a as t}from"../chunks/entry.BAkSStxi.js";export{t as start};
