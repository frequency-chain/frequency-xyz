import{a as t}from"../chunks/entry.CFO0x0BT.js";export{t as start};
