import{a as t}from"../chunks/entry.D1VSHOmE.js";export{t as start};
