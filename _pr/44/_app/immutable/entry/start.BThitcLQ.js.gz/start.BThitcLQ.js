import{a as t}from"../chunks/entry.MqPZjlRh.js";export{t as start};
