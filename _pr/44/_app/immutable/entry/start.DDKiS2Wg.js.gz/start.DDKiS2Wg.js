import{a as t}from"../chunks/entry.xOLsx1xK.js";export{t as start};
