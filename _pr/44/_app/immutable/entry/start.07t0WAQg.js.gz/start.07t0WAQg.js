import{a as t}from"../chunks/entry.0Pnfgi8U.js";export{t as start};
