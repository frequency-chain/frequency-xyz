import{a as t}from"../chunks/entry.CO142gW3.js";export{t as start};
