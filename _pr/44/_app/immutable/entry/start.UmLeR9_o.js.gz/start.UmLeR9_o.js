import{a as t}from"../chunks/entry.KHpQP2fi.js";export{t as start};
