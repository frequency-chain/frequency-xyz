import{a as t}from"../chunks/entry.b2eDzJoS.js";export{t as start};
