import{a as t}from"../chunks/entry.DM2lrcr2.js";export{t as start};
