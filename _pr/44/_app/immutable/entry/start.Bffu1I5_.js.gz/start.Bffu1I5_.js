import{a as t}from"../chunks/entry.B7MjDywr.js";export{t as start};
