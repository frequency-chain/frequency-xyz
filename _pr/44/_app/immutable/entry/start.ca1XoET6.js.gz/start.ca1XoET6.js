import{a as t}from"../chunks/entry.BU3VmSxt.js";export{t as start};
