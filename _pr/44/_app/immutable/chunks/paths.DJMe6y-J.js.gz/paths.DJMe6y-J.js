var s;const e=((s=globalThis.__sveltekit_cboho6)==null?void 0:s.base)??"/_pr/44";var a;const o=((a=globalThis.__sveltekit_cboho6)==null?void 0:a.assets)??e;export{o as a,e as b};
