import{y as s,F as l}from"./runtime.CD7lReMW.js";function u(n,t,r,a,d){var i;s&&l();var e=(i=t.$$slots)==null?void 0:i[r],f=!1;e===!0&&(e=t.children,f=!0),e===void 0||e(n,f?()=>a:a)}export{u as s};
