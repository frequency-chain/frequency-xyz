import{h as s,i as l}from"./runtime.CAtEipWX.js";function h(n,i,r,t,d){var f;s&&l();var e=(f=i.$$slots)==null?void 0:f[r],a=!1;e===!0&&(e=i.children,a=!0),e===void 0||e(n,a?()=>t:t)}export{h as s};
