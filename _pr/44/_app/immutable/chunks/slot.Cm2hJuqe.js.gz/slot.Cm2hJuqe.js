import{h as s,f as l}from"./runtime.C3AXrfkx.js";function h(n,f,r,t,d){var i;s&&l();var e=(i=f.$$slots)==null?void 0:i[r],a=!1;e===!0&&(e=f.children,a=!0),e===void 0||e(n,a?()=>t:t)}export{h as s};
