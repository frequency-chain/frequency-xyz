import{a as t}from"../chunks/entry.Dwzhbqle.js";export{t as start};
