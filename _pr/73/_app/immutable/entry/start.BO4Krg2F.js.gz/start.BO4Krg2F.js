import{a as t}from"../chunks/entry.0V9qrG1i.js";export{t as start};
