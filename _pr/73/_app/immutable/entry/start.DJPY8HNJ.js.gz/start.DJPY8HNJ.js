import{a as t}from"../chunks/entry.DozCv61Q.js";export{t as start};
