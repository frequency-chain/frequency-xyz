import{a as t}from"../chunks/entry.BqV9apJd.js";export{t as start};
