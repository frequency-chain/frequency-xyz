import{a as t}from"../chunks/entry.D3vPbjcd.js";export{t as start};
