import{A as a}from"./runtime.Djz4C1Ct.js";a();
