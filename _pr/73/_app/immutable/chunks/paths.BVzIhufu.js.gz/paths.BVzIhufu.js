var s;const t=((s=globalThis.__sveltekit_181tees)==null?void 0:s.base)??"/_pr/73";var e;const a=((e=globalThis.__sveltekit_181tees)==null?void 0:e.assets)??t;export{a,t as b};
