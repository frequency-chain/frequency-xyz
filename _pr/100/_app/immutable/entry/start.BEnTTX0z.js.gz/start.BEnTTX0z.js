import{a as t}from"../chunks/entry.D_MUt-6s.js";export{t as start};
