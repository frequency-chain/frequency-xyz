import{a as t}from"../chunks/entry.CMQS8gwh.js";export{t as start};
