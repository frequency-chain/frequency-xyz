import{a as t}from"../chunks/entry.CcY7veQM.js";export{t as start};
