import{a as t}from"../chunks/entry.ovx4F19m.js";export{t as start};
