import{a as t}from"../chunks/entry.D9LmJi6a.js";export{t as start};
