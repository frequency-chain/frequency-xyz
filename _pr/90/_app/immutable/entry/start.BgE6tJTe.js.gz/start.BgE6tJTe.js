import{a as t}from"../chunks/entry.D9BRRlMc.js";export{t as start};
