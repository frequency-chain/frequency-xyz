import{a as t}from"../chunks/entry.BLy1NK-N.js";export{t as start};
