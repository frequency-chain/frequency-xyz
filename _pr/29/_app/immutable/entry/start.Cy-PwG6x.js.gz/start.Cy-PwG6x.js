import{a as t}from"../chunks/entry.BjcwVnj1.js";export{t as start};
