import{a as t}from"../chunks/entry.DuNXYOrD.js";export{t as start};
