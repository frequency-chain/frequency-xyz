import{a as t}from"../chunks/entry.2sJJUE94.js";export{t as start};
