import{a as t}from"../chunks/entry.OGxP8Ikr.js";export{t as start};
