import{a as t}from"../chunks/entry.-QEf7wlb.js";export{t as start};
