import{a as t}from"../chunks/entry.DQpVIeSL.js";export{t as start};
