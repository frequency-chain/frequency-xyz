import{a as t}from"../chunks/entry.alGQWD2k.js";export{t as start};
