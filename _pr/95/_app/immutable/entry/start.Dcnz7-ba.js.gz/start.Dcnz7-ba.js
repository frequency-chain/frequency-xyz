import{a as t}from"../chunks/entry.CXvB-qpW.js";export{t as start};
