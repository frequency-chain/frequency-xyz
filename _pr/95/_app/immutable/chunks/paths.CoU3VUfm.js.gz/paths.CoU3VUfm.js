var s;const a=((s=globalThis.__sveltekit_4t9v4j)==null?void 0:s.base)??"/_pr/95";var t;const e=((t=globalThis.__sveltekit_4t9v4j)==null?void 0:t.assets)??a;export{e as a,a as b};
