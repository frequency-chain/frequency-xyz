var s;const e=((s=globalThis.__sveltekit_13ttmqe)==null?void 0:s.base)??"/_pr/95";var t;const a=((t=globalThis.__sveltekit_13ttmqe)==null?void 0:t.assets)??e;export{a,e as b};
