import{a as t}from"../chunks/entry.ivgyw1hy.js";export{t as start};
