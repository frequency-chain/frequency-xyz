var s;const b=((s=globalThis.__sveltekit_1ub2jbr)==null?void 0:s.base)??"/_pr/86";var a;const e=((a=globalThis.__sveltekit_1ub2jbr)==null?void 0:a.assets)??b;export{e as a,b};
