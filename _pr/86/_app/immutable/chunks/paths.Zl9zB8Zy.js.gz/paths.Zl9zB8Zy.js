var s;const e=((s=globalThis.__sveltekit_hcd9qo)==null?void 0:s.base)??"/_pr/86";var a;const t=((a=globalThis.__sveltekit_hcd9qo)==null?void 0:a.assets)??e;export{t as a,e as b};
