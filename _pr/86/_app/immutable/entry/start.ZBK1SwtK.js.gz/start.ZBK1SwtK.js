import{a as t}from"../chunks/entry.BxD9yehj.js";export{t as start};
