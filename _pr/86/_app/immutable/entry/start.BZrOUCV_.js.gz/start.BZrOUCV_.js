import{a as t}from"../chunks/entry.C0D256sJ.js";export{t as start};
