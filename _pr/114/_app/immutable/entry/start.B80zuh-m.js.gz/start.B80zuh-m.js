import{a as t}from"../chunks/CMS_o2as.js";export{t as start};
