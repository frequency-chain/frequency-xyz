import{a as t}from"../chunks/akS1SRsK.js";export{t as start};
