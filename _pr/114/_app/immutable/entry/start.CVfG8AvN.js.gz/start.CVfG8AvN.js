import{a as t}from"../chunks/C6PFrb-A.js";export{t as start};
