var s;const e=((s=globalThis.__sveltekit_lmo5dc)==null?void 0:s.base)??"/_pr/114";var a;const t=((a=globalThis.__sveltekit_lmo5dc)==null?void 0:a.assets)??e;export{t as a,e as b};
