import{a as t}from"../chunks/entry.jhSID75Y.js";export{t as start};
