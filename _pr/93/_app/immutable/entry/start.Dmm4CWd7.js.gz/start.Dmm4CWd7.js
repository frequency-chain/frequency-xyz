import{a as t}from"../chunks/entry.BmpqIk_g.js";export{t as start};
