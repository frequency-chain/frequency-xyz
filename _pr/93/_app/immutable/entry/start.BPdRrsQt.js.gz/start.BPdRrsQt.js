import{a as t}from"../chunks/entry.4G-mLBcD.js";export{t as start};
