import{a as t}from"../chunks/entry.8wtXBl4v.js";export{t as start};
