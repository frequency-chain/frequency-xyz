import{a as t}from"../chunks/entry.B1JCsMmx.js";export{t as start};
