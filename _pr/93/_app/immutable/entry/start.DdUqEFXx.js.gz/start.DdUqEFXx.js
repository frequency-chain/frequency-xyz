import{a as t}from"../chunks/entry.Di8EU_vF.js";export{t as start};
