var s;const l=((s=globalThis.__sveltekit_12nllna)==null?void 0:s.base)??"/_pr/93";var a;const e=((a=globalThis.__sveltekit_12nllna)==null?void 0:a.assets)??l;export{e as a,l as b};
