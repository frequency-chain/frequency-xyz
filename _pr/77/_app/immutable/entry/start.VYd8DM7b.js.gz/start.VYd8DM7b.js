import{a as t}from"../chunks/entry.C5pmFYkQ.js";export{t as start};
