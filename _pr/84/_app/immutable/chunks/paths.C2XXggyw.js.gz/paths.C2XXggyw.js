var s;const a=((s=globalThis.__sveltekit_o8ooc9)==null?void 0:s.base)??"/_pr/84";var o;const e=((o=globalThis.__sveltekit_o8ooc9)==null?void 0:o.assets)??a;export{e as a,a as b};
