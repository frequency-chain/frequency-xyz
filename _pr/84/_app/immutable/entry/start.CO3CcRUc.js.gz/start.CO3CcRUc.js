import{a as t}from"../chunks/entry.DTS0z4Mn.js";export{t as start};
