import{a as t}from"../chunks/entry.0DCEev-9.js";export{t as start};
