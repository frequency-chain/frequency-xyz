import{a as t}from"../chunks/entry.YSgibV_s.js";export{t as start};
