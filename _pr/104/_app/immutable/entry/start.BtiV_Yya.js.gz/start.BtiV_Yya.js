import{a as t}from"../chunks/entry.BJ5WcmCM.js";export{t as start};
