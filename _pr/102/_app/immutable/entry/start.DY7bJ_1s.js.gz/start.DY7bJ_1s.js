import{a as t}from"../chunks/entry.DRKByq8t.js";export{t as start};
