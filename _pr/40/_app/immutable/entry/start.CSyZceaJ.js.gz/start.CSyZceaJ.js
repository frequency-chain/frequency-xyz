import{a as t}from"../chunks/entry.CAZTyHAM.js";export{t as start};
