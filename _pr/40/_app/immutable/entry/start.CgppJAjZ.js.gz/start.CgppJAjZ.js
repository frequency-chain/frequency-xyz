import{a as t}from"../chunks/entry.Db9zjLZF.js";export{t as start};
