import{a as t}from"../chunks/entry.CbwcbhXc.js";export{t as start};
