var s;const a=((s=globalThis.__sveltekit_sefb3v)==null?void 0:s.base)??"/_pr/64";var e;const t=((e=globalThis.__sveltekit_sefb3v)==null?void 0:e.assets)??a;export{t as a,a as b};
