import{y as a}from"./runtime.CLPr7dZs.js";a();
