import{a as t}from"../chunks/entry.BJW1jYgq.js";export{t as start};
