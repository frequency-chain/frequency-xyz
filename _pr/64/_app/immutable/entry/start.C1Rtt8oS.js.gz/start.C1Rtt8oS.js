import{a as t}from"../chunks/entry.BgXKAATI.js";export{t as start};
