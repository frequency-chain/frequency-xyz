import{a as t}from"../chunks/entry.CjktPGo-.js";export{t as start};
