import{a as t}from"../chunks/entry.C-_PkWPN.js";export{t as start};
