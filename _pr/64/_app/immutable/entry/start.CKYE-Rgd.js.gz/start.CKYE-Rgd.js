import{a as t}from"../chunks/entry.D0C9uYjo.js";export{t as start};
