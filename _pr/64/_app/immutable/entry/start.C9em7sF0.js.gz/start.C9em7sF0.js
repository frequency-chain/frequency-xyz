import{a as t}from"../chunks/entry.HhbZ1Abf.js";export{t as start};
