import{a as t}from"../chunks/entry.r2K2CRcO.js";export{t as start};
