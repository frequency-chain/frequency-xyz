import{a as t}from"../chunks/entry.Bym25y2L.js";export{t as start};
