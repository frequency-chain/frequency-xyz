import{a as t}from"../chunks/entry.Cruu-9Bz.js";export{t as start};
