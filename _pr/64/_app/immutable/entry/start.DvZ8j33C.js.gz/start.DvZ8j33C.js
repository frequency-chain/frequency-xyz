import{a as t}from"../chunks/entry.BfAwzbDz.js";export{t as start};
