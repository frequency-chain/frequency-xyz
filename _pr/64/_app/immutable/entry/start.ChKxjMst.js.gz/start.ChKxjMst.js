import{a as t}from"../chunks/entry.D_p9qvEd.js";export{t as start};
