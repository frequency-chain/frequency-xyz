import{a as t}from"../chunks/entry.M0t6dyH9.js";export{t as start};
