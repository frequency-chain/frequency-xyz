import{a as t}from"../chunks/entry.CtaYQ3Mp.js";export{t as start};
