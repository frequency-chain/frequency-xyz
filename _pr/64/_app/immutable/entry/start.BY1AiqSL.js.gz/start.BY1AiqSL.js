import{a as t}from"../chunks/entry.Cf8yYUSo.js";export{t as start};
