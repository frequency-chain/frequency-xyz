import{a as t}from"../chunks/entry.xBzlyVii.js";export{t as start};
