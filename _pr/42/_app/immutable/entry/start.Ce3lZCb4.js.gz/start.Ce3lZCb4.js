import{a as t}from"../chunks/entry.vT8Qx6Cq.js";export{t as start};
