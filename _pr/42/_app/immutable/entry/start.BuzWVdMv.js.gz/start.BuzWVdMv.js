import{a as t}from"../chunks/entry.BoQltZk8.js";export{t as start};
