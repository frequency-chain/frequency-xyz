import{a as t}from"../chunks/entry.cXnYmxGn.js";export{t as start};
