import{a as t}from"../chunks/entry.DoxHYWFh.js";export{t as start};
