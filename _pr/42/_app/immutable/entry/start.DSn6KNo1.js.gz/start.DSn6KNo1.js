import{a as t}from"../chunks/entry.JMLV4wXF.js";export{t as start};
