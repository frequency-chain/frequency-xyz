import{a as t}from"../chunks/entry.B77nvAGS.js";export{t as start};
