import{a as t}from"../chunks/entry.CxgR_6gn.js";export{t as start};
