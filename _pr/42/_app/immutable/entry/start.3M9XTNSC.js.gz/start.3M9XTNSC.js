import{a as t}from"../chunks/entry.CjvwW_3t.js";export{t as start};
