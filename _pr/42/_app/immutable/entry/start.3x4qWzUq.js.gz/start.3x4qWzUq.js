import{a as t}from"../chunks/entry.BVURkbL4.js";export{t as start};
