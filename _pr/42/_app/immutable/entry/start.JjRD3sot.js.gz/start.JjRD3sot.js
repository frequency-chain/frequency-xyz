import{a as t}from"../chunks/entry.Cg8_58io.js";export{t as start};
