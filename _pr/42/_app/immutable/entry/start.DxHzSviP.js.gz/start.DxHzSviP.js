import{a as t}from"../chunks/entry.DiDY47Gh.js";export{t as start};
