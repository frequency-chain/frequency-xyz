import{a as t}from"../chunks/entry.qmqufed-.js";export{t as start};
