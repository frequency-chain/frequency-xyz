import{a as t}from"../chunks/entry.wOA71hKY.js";export{t as start};
