import{a as t}from"../chunks/entry.D7Vy8Xri.js";export{t as start};
