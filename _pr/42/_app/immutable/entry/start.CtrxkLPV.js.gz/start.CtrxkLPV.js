import{a as t}from"../chunks/entry._gDFxels.js";export{t as start};
