import{a as t}from"../chunks/entry.ChxfAMkE.js";export{t as start};
