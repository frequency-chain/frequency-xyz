import{a as t}from"../chunks/entry.Ccu5HZb-.js";export{t as start};
