import{a as t}from"../chunks/entry.hj8pqiho.js";export{t as start};
