import{a as t}from"../chunks/entry.CtjXm7W6.js";export{t as start};
