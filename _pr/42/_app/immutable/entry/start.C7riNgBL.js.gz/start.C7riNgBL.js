import{a as t}from"../chunks/entry.8OyJKp4x.js";export{t as start};
