import{a as t}from"../chunks/entry.Tzvqa82t.js";export{t as start};
