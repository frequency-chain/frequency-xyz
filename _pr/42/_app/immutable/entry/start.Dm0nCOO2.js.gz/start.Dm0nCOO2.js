import{a as t}from"../chunks/entry.DkyPJw-V.js";export{t as start};
