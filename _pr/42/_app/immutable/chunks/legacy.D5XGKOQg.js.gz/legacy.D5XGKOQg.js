import{y as a}from"./runtime.Jj8XJZyx.js";a();
