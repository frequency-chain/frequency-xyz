import{h as s,x as l}from"./runtime.BqXve3Ni.js";function h(n,t,r,a,d){var i;s&&l();var e=(i=t.$$slots)==null?void 0:i[r],f=!1;e===!0&&(e=t.children,f=!0),e===void 0||e(n,f?()=>a:a)}export{h as s};
