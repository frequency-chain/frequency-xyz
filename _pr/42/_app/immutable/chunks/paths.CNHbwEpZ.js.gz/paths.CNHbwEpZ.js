var s;const a=((s=globalThis.__sveltekit_k49ftg)==null?void 0:s.base)??"/_pr/42";var t;const e=((t=globalThis.__sveltekit_k49ftg)==null?void 0:t.assets)??a;export{e as a,a as b};
