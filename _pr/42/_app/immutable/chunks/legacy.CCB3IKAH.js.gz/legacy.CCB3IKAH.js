import{F as a}from"./runtime.Cpnby2Ob.js";a();
