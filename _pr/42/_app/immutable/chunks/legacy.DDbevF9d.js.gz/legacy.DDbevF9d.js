import{F as a}from"./runtime.Dca_6ewH.js";a();
