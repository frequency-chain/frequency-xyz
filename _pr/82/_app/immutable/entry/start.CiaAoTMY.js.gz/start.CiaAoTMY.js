import{a as t}from"../chunks/entry.BhiD51le.js";export{t as start};
