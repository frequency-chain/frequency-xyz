import{a as t}from"../chunks/entry.CRUASW9D.js";export{t as start};
