import{a as t}from"../chunks/entry.tqcMix3o.js";export{t as start};
