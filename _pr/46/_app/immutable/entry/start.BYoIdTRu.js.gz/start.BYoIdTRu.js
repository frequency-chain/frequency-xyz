import{a as t}from"../chunks/entry.B7z9zDLQ.js";export{t as start};
