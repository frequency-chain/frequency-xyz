import{a as t}from"../chunks/entry.BRDj-kxq.js";export{t as start};
