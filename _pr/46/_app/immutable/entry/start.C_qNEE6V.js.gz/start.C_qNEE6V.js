import{a as t}from"../chunks/entry.BXtR_hip.js";export{t as start};
