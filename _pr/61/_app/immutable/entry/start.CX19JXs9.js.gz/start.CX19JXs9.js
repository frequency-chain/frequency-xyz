import{a as t}from"../chunks/entry.DLsuRcRM.js";export{t as start};
