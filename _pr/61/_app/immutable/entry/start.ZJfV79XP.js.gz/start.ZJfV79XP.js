import{a as t}from"../chunks/entry.CPL3pbOD.js";export{t as start};
