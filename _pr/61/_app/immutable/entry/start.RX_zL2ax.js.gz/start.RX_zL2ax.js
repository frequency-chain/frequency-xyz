import{a as t}from"../chunks/entry.CIA5Fm8D.js";export{t as start};
