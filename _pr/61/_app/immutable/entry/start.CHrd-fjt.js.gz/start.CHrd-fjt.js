import{a as t}from"../chunks/entry.DUpO8ys5.js";export{t as start};
