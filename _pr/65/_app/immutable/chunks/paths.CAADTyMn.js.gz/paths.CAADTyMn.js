var s;const t=((s=globalThis.__sveltekit_oa5tnf)==null?void 0:s.base)??"/_pr/65";var a;const e=((a=globalThis.__sveltekit_oa5tnf)==null?void 0:a.assets)??t;export{e as a,t as b};
