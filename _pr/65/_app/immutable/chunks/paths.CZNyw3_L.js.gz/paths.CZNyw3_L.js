var s;const a=((s=globalThis.__sveltekit_wl5zbl)==null?void 0:s.base)??"/_pr/65";var l;const e=((l=globalThis.__sveltekit_wl5zbl)==null?void 0:l.assets)??a;export{e as a,a as b};
