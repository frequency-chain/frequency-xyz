import{a as t}from"../chunks/entry.DrIZsxSI.js";export{t as start};
