import{a as t}from"../chunks/entry.C5URkfnr.js";export{t as start};
