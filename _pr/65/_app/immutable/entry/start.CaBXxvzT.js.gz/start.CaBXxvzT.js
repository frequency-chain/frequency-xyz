import{a as t}from"../chunks/entry.DfPX871X.js";export{t as start};
