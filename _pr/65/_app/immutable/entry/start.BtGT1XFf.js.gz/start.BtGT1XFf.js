import{a as t}from"../chunks/entry.B3i_IwQg.js";export{t as start};
