import{a as t}from"../chunks/entry.CRJ43zZr.js";export{t as start};
