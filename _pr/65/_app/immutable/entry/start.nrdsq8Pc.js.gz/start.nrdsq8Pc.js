import{a as t}from"../chunks/entry.Cf7EqFdB.js";export{t as start};
