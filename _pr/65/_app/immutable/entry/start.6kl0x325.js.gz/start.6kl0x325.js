import{a as t}from"../chunks/entry.Btf37qao.js";export{t as start};
