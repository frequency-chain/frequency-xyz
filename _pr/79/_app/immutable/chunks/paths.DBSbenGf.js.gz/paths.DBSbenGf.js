var s;const t=((s=globalThis.__sveltekit_1t9rjek)==null?void 0:s.base)??"/_pr/79";var e;const a=((e=globalThis.__sveltekit_1t9rjek)==null?void 0:e.assets)??t;export{a,t as b};
