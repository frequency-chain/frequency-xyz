var s;const b=((s=globalThis.__sveltekit_1dc2bbw)==null?void 0:s.base)??"/_pr/79";var a;const e=((a=globalThis.__sveltekit_1dc2bbw)==null?void 0:a.assets)??b;export{e as a,b};
