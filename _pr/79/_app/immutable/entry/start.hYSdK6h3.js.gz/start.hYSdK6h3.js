import{a as t}from"../chunks/entry.aFxp5Tr4.js";export{t as start};
