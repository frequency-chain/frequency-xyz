import{a as t}from"../chunks/entry.COk3bC3T.js";export{t as start};
