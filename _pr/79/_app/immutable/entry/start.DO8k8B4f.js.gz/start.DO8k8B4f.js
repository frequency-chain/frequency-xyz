import{a as t}from"../chunks/entry.D0qlwGpD.js";export{t as start};
