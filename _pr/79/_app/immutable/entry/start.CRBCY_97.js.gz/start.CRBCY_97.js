import{a as t}from"../chunks/entry.Cfph-O_J.js";export{t as start};
