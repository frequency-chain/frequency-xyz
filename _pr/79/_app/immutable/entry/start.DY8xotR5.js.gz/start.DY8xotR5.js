import{a as t}from"../chunks/entry.BUlgmFl-.js";export{t as start};
