import{a as t}from"../chunks/entry.D4w9W_8w.js";export{t as start};
