import{a as t}from"../chunks/entry.wHYn61ZZ.js";export{t as start};
