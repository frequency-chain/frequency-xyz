import{a as t}from"../chunks/entry.zTEy-7IJ.js";export{t as start};
