import{a as t}from"../chunks/entry.BuiA8Lcr.js";export{t as start};
