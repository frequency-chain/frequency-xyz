import{a as t}from"../chunks/entry.BQkSZFTd.js";export{t as start};
