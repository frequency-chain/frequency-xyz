import{C as a}from"./runtime.DKAJWjv-.js";a();
