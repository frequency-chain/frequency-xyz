import{a as t}from"../chunks/entry.BJpOte6U.js";export{t as start};
