import{a as t}from"../chunks/entry.B4mc52uD.js";export{t as start};
