import{a as t}from"../chunks/entry.CFA5twS6.js";export{t as start};
