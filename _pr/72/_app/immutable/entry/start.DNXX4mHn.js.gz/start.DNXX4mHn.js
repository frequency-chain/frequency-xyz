import{a as t}from"../chunks/entry.B7okpgUk.js";export{t as start};
