import{a as t}from"../chunks/entry.DM0muFYn.js";export{t as start};
