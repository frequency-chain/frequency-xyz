import{a as t}from"../chunks/entry.Cfd-G0SC.js";export{t as start};
