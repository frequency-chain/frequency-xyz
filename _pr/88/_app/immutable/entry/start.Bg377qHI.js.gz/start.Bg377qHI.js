import{a as t}from"../chunks/entry.CAJObb5G.js";export{t as start};
