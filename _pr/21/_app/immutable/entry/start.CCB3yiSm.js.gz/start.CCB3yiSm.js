import{a as t}from"../chunks/entry.BTmhSNh8.js";export{t as start};
