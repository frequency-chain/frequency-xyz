import{a as t}from"../chunks/entry.DOtVLOSn.js";export{t as start};
