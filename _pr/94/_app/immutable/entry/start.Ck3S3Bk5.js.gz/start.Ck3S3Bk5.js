import{a as t}from"../chunks/entry.BrLzsy0d.js";export{t as start};
