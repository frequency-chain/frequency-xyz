import{a as t}from"../chunks/entry.DRCL7fIQ.js";export{t as start};
