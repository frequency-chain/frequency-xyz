import{a as t}from"../chunks/entry.CvzpEMpk.js";export{t as start};
