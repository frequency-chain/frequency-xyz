import{a as t}from"../chunks/entry.B4zr7vNb.js";export{t as start};
