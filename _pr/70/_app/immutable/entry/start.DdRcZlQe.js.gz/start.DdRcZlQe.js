import{a as t}from"../chunks/entry.BqFKlq2u.js";export{t as start};
